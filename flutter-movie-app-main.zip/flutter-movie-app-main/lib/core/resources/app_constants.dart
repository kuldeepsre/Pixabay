class AppConstants {
  static const int carouselSliderItemsCount = 4;
}
