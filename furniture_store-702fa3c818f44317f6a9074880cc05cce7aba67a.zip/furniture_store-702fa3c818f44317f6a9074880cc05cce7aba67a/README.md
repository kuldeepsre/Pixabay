# furniture_store

A Furniture Store design.

<img src="1.png" width="30%" height="30%"> <img src="2.png" width="30%" height="30%"> <img src="3.png" width="30%" height="30%">
