package com.example.fcm_push_notification

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
