class ImageConstant {
  static String imgImage8 = 'assets/images/img_image8.png';

  static String imgRectangle14 = 'assets/images/img_rectangle14.png';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgStar12 = 'assets/images/img_star1_2.svg';

  static String imgVector1 = 'assets/images/img_vector1.svg';

  static String imgLock40x40 = 'assets/images/img_lock_40x40.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgVector2 = 'assets/images/img_vector2.svg';

  static String imgRectangle12 = 'assets/images/img_rectangle12.png';

  static String imgHeroimage = 'assets/images/img_heroimage.png';

  static String imgRectangle11 = 'assets/images/img_rectangle11.png';

  static String imgImage7 = 'assets/images/img_image7.png';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgReturn = 'assets/images/img_return.svg';

  static String imgImage3 = 'assets/images/img_image3.png';

  static String imgSearchBluegray900 =
      'assets/images/img_search_bluegray_900.svg';

  static String imgRectangle13 = 'assets/images/img_rectangle13.png';

  static String imgSelected = 'assets/images/img_selected.png';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgVuesaxBulkPeople =
      'assets/images/img_vuesax_bulk_people.svg';

  static String imgImage7278x220 = 'assets/images/img_image7_278x220.png';

  static String imgStar11 = 'assets/images/img_star1_1.svg';

  static String imgImage8278x262 = 'assets/images/img_image8_278x262.png';

  static String imgSlider = 'assets/images/img_slider.png';

  static String imgStar115x15 = 'assets/images/img_star1_15x15.svg';

  static String imgStar1 = 'assets/images/img_star1.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
