class ProductDetailsPageModel {}
