class SplashModel {}
