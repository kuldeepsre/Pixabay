import 'package:manish_s_application4/core/app_export.dart';

class ApiClient extends GetConnect {}
