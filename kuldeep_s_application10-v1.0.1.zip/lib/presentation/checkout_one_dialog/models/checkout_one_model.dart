// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';/// This class defines the variables used in the [checkout_one_dialog],
/// and is typically used to hold data that is passed between different parts of the application.
class CheckoutOneModel extends Equatable {CheckoutOneModel() {  }

CheckoutOneModel copyWith() { return CheckoutOneModel(
); } 
@override List<Object?> get props => [];
 }
