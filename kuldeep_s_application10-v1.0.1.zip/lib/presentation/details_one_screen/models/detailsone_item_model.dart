import '../../../core/app_export.dart';/// This class is used in the [detailsone_item_widget] screen.
class DetailsoneItemModel {DetailsoneItemModel({this.group, this.id, }) { group = group  ?? ImageConstant.imgGroup138;id = id  ?? ""; }

String? group;

String? id;

 }
