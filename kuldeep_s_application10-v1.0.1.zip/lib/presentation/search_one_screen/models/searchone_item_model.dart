import '../../../core/app_export.dart';/// This class is used in the [searchone_item_widget] screen.
class SearchoneItemModel {SearchoneItemModel({this.nikeAirMaxShoes, this.id, }) { nikeAirMaxShoes = nikeAirMaxShoes  ?? "Nike Air Max Shoes";id = id  ?? ""; }

String? nikeAirMaxShoes;

String? id;

 }
