package com.example.fluxestore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
