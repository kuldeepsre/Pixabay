import '../../models/product_data_model.dart';

List<ProductDataModel> wishListedItems = [];
