part of 'home_bloc.dart';

@immutable
sealed class HomePageEvent {}


class HomePageInitialEvent extends HomePageEvent{}
