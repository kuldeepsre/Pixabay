part of 'products_page_bloc.dart';

@immutable
sealed class ProductsPageEvent {}

class ProductsPageInitialevent extends ProductsPageEvent{}
