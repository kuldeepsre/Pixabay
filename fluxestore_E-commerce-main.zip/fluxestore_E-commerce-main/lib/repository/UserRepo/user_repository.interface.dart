
abstract class IUserRepository {
  Future<Map<String, dynamic>>  getUserDetails(String userId);
}
