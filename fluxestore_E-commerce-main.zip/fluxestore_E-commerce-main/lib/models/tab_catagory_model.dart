class TabCategoryModel {
  final String title;
  bool isSelected;
  TabCategoryModel(this.title, this.isSelected);
}