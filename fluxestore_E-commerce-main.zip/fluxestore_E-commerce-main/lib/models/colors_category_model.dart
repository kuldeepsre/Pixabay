
class ColorsCatagoryModel {
  final int color;
   bool selectedColor;

  ColorsCatagoryModel( this.color, this.selectedColor);
  
}
