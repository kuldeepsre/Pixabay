   const String appTitle = 'Movies App';
   const String seeAll = 'see all';
   const String popularMovies = 'Popular movies';
   const String topRatedMovies = 'Top rated movies';
   const String story = 'Story';
   const String videos = 'Videos';
   const String cast = 'Cast';
   const String reviews = 'Reviews';
   const String similar = 'Similar';
   const String showLess = 'Show less';
   const String showMore = 'Show more';
   const String movies = 'Movies';
   const String shows = 'Shows';
   const String search = 'Search';
   const String watchlist = 'Watchlist';
   const String popularShows = 'Popular shows';
   const String topRatedShows = 'Top rated shows';
   const String lastEpisodeOnAir = 'Last Episode on Air';
   const String seasons = 'Seasons';
   const String season = 'Season';
   const String episodes = 'Episodes';
   const String episode = 'Episode';
   const String airDate = 'Air date:';
   const String lastEpisode = 'Last Episode';
   const String searchText =
      'By typing in search bar, Movia search in movies and series and then show you the best results.';
   const String searchHint = 'Search for Movies, Series...';
   const String watchlistIsEmpty = 'Watchlist is empty';
   const String watchlistText =
      'After adding movies and series to watchlist, they will appear here.';
   const String oops = 'Ooops';
   const String tryAgainLater = 'Please try again later';
   const String errorMessage = 'Something went wrong';
   const String tryAgain = 'try again';
   const String noResults = 'No results';

