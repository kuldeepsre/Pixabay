enum RequestStatus { loading, loaded, error }

enum GetAllRequestStatus { loading, loaded, error, fetchMoreError }
