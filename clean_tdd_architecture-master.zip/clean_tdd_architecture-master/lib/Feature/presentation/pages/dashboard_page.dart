import 'package:flutter/material.dart';

class DashboardPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return DashboardPageState();
  }
  
}
class DashboardPageState extends State<DashboardPage>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      child: Text("Home"),
    );
  }
  
}