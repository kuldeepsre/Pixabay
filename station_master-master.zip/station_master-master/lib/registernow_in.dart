// ignore_for_file: prefer_const_constructors

import 'package:flutter/services.dart';
import 'package:station_master/custom_widget/custom_button.dart';
import 'package:station_master/sign_in.dart';
import 'package:station_master/utils/custom_dialog.dart';

import 'package:station_master/tabs/home_scrrem.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/strings.dart';
import 'package:station_master/utils/text_style.dart';
import 'package:flutter/material.dart';

import 'bloc/gate_bloc/gate_bloc.dart';
import 'custom_widget/custom_loader.dart';
import 'custom_widget/custom_text_white_normal.dart';

import 'package:flutter_bloc/flutter_bloc.dart';



class RegisterNow extends StatefulWidget {
  const RegisterNow({Key? key}) : super(key: key);

  @override
  _GateScreenState createState() => _GateScreenState();
}

class _GateScreenState extends State<RegisterNow> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => GateBloc(GateInitial()),
      child: const Gate2Widget(),
    );
  }
}

class Gate2Widget extends StatefulWidget {
  const Gate2Widget({Key? key}) : super(key: key);
  @override
  _GateWidgetState createState() => _GateWidgetState();
}

class _GateWidgetState extends State<Gate2Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  late bool _validate;
  late bool isLogin;
  var selectProject = "";
  final statusDateControoler = TextEditingController();
  var emailController=TextEditingController(text: "");
  var passController=TextEditingController(text: "");
  var idController=TextEditingController(text: "");
  var addressController=TextEditingController(text: "");
  var phoneController=TextEditingController(text: "");
  var ownerController=TextEditingController(text: "");
  String pattern =
      r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
      r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
      r"{0,253}[a-zA-Z0-9])?)*$";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    final gateBloc = BlocProvider.of<GateBloc>(context);
    return SafeArea(
      child: Scaffold(
      
        /*  appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.transparent,
          ),*/

          body: BlocListener<GateBloc, GateState>(
            listener: (context, state) {
              if(state is DataSaved){

                CustomDialogs.showDialogMessage(
                    context, state.message, state.title);
                Future.delayed(Duration(seconds: 3), () {
                  gateBloc.add(GateEventInitial());
                });

              }
              if(state is DataFailed){
                CustomDialogs.showDialogForError(
                    context, state.message, state.title);
              }
            },
            child: BlocBuilder(
              bloc: gateBloc,
              builder: (BuildContext context, GateState state) {
                if (state is GateLoading) {
                  return const CustomLoader();
                }
             return Stack(

               children: [
                 SizedBox(
                   width:MediaQuery.of(context).size.width,
                   height:MediaQuery.of(context).size.height,
                   child: Image.asset("assets/sm/bg.png",fit: BoxFit.fill,),
                 ),
                 Form(
                   key: formKey,
                   child: SingleChildScrollView(
                     child: Column(
                       crossAxisAlignment: CrossAxisAlignment.center,
                       mainAxisAlignment: MainAxisAlignment.start,
                       children:  <Widget>[
                         Container(
                           width:MediaQuery.of(context).size.width,
                           height:MediaQuery.of(context).size.height*.30,
                           child: Image.asset("assets/sm/top.png",fit: BoxFit.fill,),
                         ),
                         Text(
                           "Register Now".toUpperCase(),
                           textScaleFactor: 1,
                           style: sideMenuStyle,
                         ),
                         const SizedBox(height: 20,),
                         Text(
                           "Please Register to get credential",
                           textScaleFactor: 1,
                           style: graySubHeadingStyle,
                         ),
                         const SizedBox(height: 10,),
                         Padding(
                           padding: const EdgeInsets.all(8.0),
                           child: ListView(
                             physics: NeverScrollableScrollPhysics(),
                             shrinkWrap: true,
                             children: [
                               TextFormField(
                                 controller: ownerController,
                                 keyboardType: TextInputType.text,
                                 decoration: InputDecoration(
                                   filled: true,
                                   fillColor: ColorUtils.bgText,


                                   focusedBorder: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color)),
                                   border: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color,
                                           width: 0.5) //This is Ignored,

                                   ),

                                   labelStyle: TextStyle(
                                       color: ColorUtils.whiteColor),
                                   hintText: "",
                                   labelText: "Owner Name",
                                   hintStyle: const TextStyle(color: Colors.white),
                                 ),

                                 autocorrect: true,
                                 style:
                                 TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                 validator: (value) {
                                   if (value == null || value.isEmpty) {
                                     return "Please Enter Owner Name";
                                   } else {
                                     return null;
                                   }
                                 },

                               ),
                               const SizedBox(height: 20,),
                               TextFormField(
                                 controller: passController,
                                 keyboardType: TextInputType.text,
                                 decoration: InputDecoration(
                                   filled: true,
                                   fillColor: ColorUtils.bgText,

                                   focusedBorder: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color)),
                                   border: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color,
                                           width: 0.5) //This is Ignored,

                                   ),
                                   labelStyle: TextStyle(
                                       color: ColorUtils.whiteColor),
                                   hintText: "",
                                   labelText: "Password",

                                   hintStyle: const TextStyle(color: Colors.white),
                                 ),
                                 autocorrect: true,
                                 style:
                                 TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                 validator: (value) {
                                   if (value == null || value.isEmpty) {
                                     return "Please enter password";
                                   } else {
                                     return null;
                                   }
                                 },
                                 onChanged: (text) {
                                   setState(() {});
                                   // do something with text
                                 },
                               ),
                               const SizedBox(height: 10,),
                               TextFormField(
                                 controller: idController,
                                 keyboardType: TextInputType.text,
                                 decoration: InputDecoration(
                                   filled: true,
                                   fillColor: ColorUtils.bgText,

                                   focusedBorder: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color)),
                                   border: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color,
                                           width: 0.5) //This is Ignored,

                                   ),
                                   labelStyle: TextStyle(
                                       color: ColorUtils.whiteColor),
                                   hintText: "",
                                   labelText: "Owner ID Proof any",
                                   hintStyle: const TextStyle(color: Colors.white),
                                 ),
                                 autocorrect: true,
                                 style:
                                 TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                 validator: (value) {
                                   if (value == null || value.isEmpty) {
                                     return "Please enter Owner ID Proof any";
                                   } else {
                                     return null;
                                   }
                                 },
                                 onChanged: (text) {
                                   setState(() {});
                                   // do something with text
                                 },
                               ),
                               const SizedBox(height: 10,),
                               TextFormField(
                                 controller: addressController,
                                 keyboardType: TextInputType.text,
                                 decoration: InputDecoration(
                                   filled: true,
                                   fillColor: ColorUtils.bgText,

                                   focusedBorder: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color)),
                                   border: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color,
                                           width: 0.5) //This is Ignored,

                                   ),
                                   labelStyle: TextStyle(
                                       color: ColorUtils.whiteColor),
                                   hintText: "",
                                   labelText: "Address",
                                   hintStyle: const TextStyle(color: Colors.white),
                                 ),
                                 autocorrect: true,
                                 style:
                                 TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                 validator: (value) {
                                   if (value == null || value.isEmpty) {
                                     return "Address";
                                   } else {
                                     return null;
                                   }
                                 },
                                 onChanged: (text) {
                                   setState(() {});
                                   // do something with text
                                 },
                               ),
                               const SizedBox(height: 10,),
                               TextFormField(
                                 controller: phoneController,
                                 keyboardType: TextInputType.number,
                                 inputFormatters: [
                                   new LengthLimitingTextInputFormatter(10),
                                 ],
                                 decoration: InputDecoration(
                                   filled: true,
                                   fillColor: ColorUtils.bgText,
                                   focusedBorder: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color)),
                                   border: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color,
                                           width: 0.5) //This is Ignored,

                                   ),
                                   labelStyle: TextStyle(
                                       color: ColorUtils.whiteColor),
                                   hintText: "",
                                   labelText: "Phone Number",
                                   hintStyle: const TextStyle(color: Colors.white),
                                 ),
                                 autocorrect: true,
                                 style:
                                 TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                 validator: (value) {
                                   if (value == null || value.isEmpty) {
                                     return "Phone Number";
                                   } else {
                                     return null;
                                   }
                                 },
                                 onChanged: (text) {
                                   setState(() {});
                                   // do something with text
                                 },
                               ),
                               const SizedBox(height: 10,),
                               TextFormField(
                                 controller: emailController,
                                 keyboardType: TextInputType.text,
                                 decoration: InputDecoration(
                                   filled: true,
                                   fillColor: ColorUtils.bgText,

                                   focusedBorder: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color)),
                                   border: OutlineInputBorder(
                                       borderSide: BorderSide(
                                           color: ColorUtils.app_primary_color,
                                           width: 0.5) //This is Ignored,

                                   ),
                                   labelStyle: TextStyle(
                                       color: ColorUtils.whiteColor),
                                   hintText: "",
                                   labelText: "Email ID",
                                   hintStyle: const TextStyle(color: Colors.white),
                                 ),
                                 autocorrect: true,
                                 style:
                                 TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                 validator: (value) {
                                   RegExp regex = RegExp(pattern);
                                   if (value == null || value.isEmpty || !regex.hasMatch(value)) {
                                     return 'Enter a valid email address';
                                   } else {
                                     return null;
                                   }
                                 },
                                 onChanged: (text) {
                                   setState(() {});
                                   // do something with text
                                 },
                               ),
                               const SizedBox(height: 10,),
      /*                               Align(
                                   alignment: Alignment.topRight,
                                   child: const CustomTextWhiteNormal(Strings.forgotPass)),
                               const SizedBox(height: 10,),*/

                               SizedBox(
                                 width: MediaQuery.of(context).size.width,
                                 child: CustomButton("Register", onClick: () {

                                   if (formKey.currentState!.validate()){
                                     save(context);
                                   }
                                 }, isFullWidth: true),
                               ),
                               const SizedBox(height: 10,),
                               Row(
                                 mainAxisAlignment: MainAxisAlignment.center,
                                 children:  [
                                   CustomTextWhiteNormal("Already register ? "),
                                   GestureDetector(
                                       onTap: (){
                                         Navigator.pushAndRemoveUntil(
                                             context,
                                             MaterialPageRoute(
                                                 builder: (BuildContext context) =>
                                                     SignIn()),
                                                 (Route<dynamic> route) => route.isFirst);
                                       },
                                       child: CustomTextWhiteNormal(Strings.login)),
                                 ],
                               )
                             ],
                           ),
                         ),


                       ],
                     ),
                   ),
                 ),
               ],
             );

              },
            ),
          )
      ),
    );
  }
  void save(BuildContext context) {
    final gateBloc = BlocProvider.of<GateBloc>(context);
    gateBloc.add(AddInfo(
      password:passController.text.toString(),
      owner_name:ownerController.text.toString(),
      id_proof:idController.text.toString(),
      address:addressController.text.toString(),
      phone:phoneController.text.toString(),
      email:emailController.text.toString(),

    ));
  }
}