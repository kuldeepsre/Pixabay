bool tableAlreadyCreated = false;
String prevPath = "";
