const String loginScreenRoute = '/loginScreenRoute';

const String homeScreenRoute = '/homeScreenRoute';
const String selectionHomeRoute = '/selectionHomeRoute';
const String selectionRoute = '/selectionRoute';

const String guestAssistant1Route = '/guestAssistant1Route';
const String guestAssistant2Route = '/guestAssistant2Route';
const String guestAssistant3Route = '/guestAssistant3Route';

const String callForVehicle1Route = '/callForVehicle1Route';
const String callForVehicle2Route = '/callForVehicle2Route';
const String callForVehicle3Route = '/callForVehicle3Route';

const String pickupGate2Route = '/pickupGate2Route';
const String pickupGate3Route = '/pickupGate3Route';

const String dropGate1Route = '/dropGate1Route';
const String dropGate2Route = '/dropGate2Route';
const String dropGate3Route = '/dropGate3Route';

const String gateOneScreenSaveRoute = '/gateOneScreenSaveRoute';
const String gate2ScreenSaveRoute = '/gate2ScreenSaveRoute';
const String gate3ScreenSaveRoute = '/gate3ScreenSaveRoute';

const String gate1ScreenRoute = '/gate1ScreenRoute';
const String giftEntryRoute = '/giftEntryRoute';
const String guestSaveScreenRoute = '/guestSaveScreenRoute';
const String admin = '/admin';
const String savegift = '/savegift';
const String addEvent = '/addEvent';
const String reports = '/reports';
const String reportdatas = '/reportdatas';
const String viewCallForVehicle = '/viewCallForVehicle';
const String addfamilyvehicle = '/addfamilyvehicle';
const String parkingSaveScreenRoute = '/parkingSaveScreenRoute';
