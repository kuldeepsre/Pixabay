import 'dart:convert';

import 'package:station_master/bloc/gate_bloc/gate_bloc.dart';
import 'package:station_master/model/battry_list_response.dart';
import 'package:station_master/model/login_response.dart';
import 'package:station_master/model/my_plan_response.dart';
import 'package:station_master/model/register_response.dart';
import 'package:station_master/model/subscription_response.dart';
import 'package:station_master/utils/Constants.dart';
import 'package:station_master/utils/text_style.dart';
import 'package:station_master/utils/utils.dart';
import 'package:http/http.dart' as http;

import '../model/common_response.dart';
import '../model/get_battry_list_response.dart';
import '../model/swap_now_response.dart';

abstract class Services {

  
}
class FetchService extends Services {
  @override
  Future<RegisterResponse>  saveRagister(  String owner_name,String password,
      String phone,String address,String id_proof,String email
  )
  async {
    var res = await Utils.postApiCall(Constants.REGISTER_API_URL, {
      'owner_name': owner_name,
      "password": password,
      "owner_id_proof": id_proof,
      "phone": phone,
      "address": address,
      "email": email,

    });
    var data = json.decode(res.body);
    return RegisterResponse.fromJson(data);
  }
  @override
  Future<LoginData> saveLogin (
  String email, String password) async {
    var res = await Utils.postApiCall(Constants.LOGIN_API_URL, {
      'login_user_id': email,
      "password": password,

    });


    var jsonresult = json.decode(res.body);
    LoginData  loginResponse=LoginData.fromJson(jsonresult);

    if(loginResponse.status==200)

    {
      Constants.userId=loginResponse.success!.userData!.loginUserId.toString();
      Constants.email=loginResponse.success!.userData!.email.toString();
      Constants.swapstation_id=loginResponse.success!.userData!.swapstation_id.toString();
      Constants.phone=loginResponse.success!.userData!.phone.toString();
      Constants.address=loginResponse.success!.userData!.address.toString();
      Constants.owner_name=loginResponse.success!.userData!.ownerName.toString();
      Constants.owner_id_proof=loginResponse.success!.userData!.ownerIdProof.toString();


    }
    return loginResponse;

  }
  @override
  Future<RegisterResponse> saveMove (
  String id,String battery_id) async {
    var res = await Utils.postApiCall(Constants.MOVE_API_URL, {
      "swapstation_id": id,
       'battery_id': battery_id,


    });


    var jsonresult = json.decode(res.body);
    RegisterResponse  loginResponse=RegisterResponse.fromJson(jsonresult);

    return loginResponse;

  }
  @override
  Future<RegisterResponse> saveDefected (
  String id,String remark,String battery_id) async {
    var res = await Utils.postApiCall(Constants.MOVE_API_URL, {
      "swapstation_id": id,
      'remark': remark,
      'battery_id': battery_id,


    });


    var jsonresult = json.decode(res.body);
    RegisterResponse  loginResponse=RegisterResponse.fromJson(jsonresult);

    return loginResponse;

  }

  @override
  Future<SubscriptionResponseList> getSubscriptionList (
  String userId) async {
    var res = await Utils.postApiCall(Constants.POST_SWAP_HISTORY, {
      "ev_number":userId,

    });


    var jsonresult = json.decode(res.body);
      SubscriptionResponseList  subscriptionResponseList=SubscriptionResponseList.fromJson(jsonresult);
        if(subscriptionResponseList.status==200){
            GlobleConstant.batterySerialNo =subscriptionResponseList.success!.data!.batterySerialNo;
            GlobleConstant.subscription_id =subscriptionResponseList.success!.data!.subscriptionId.toString();
            GlobleConstant.freeSwap =subscriptionResponseList.success!.data!.freeSwap;
            GlobleConstant.totalSwap =subscriptionResponseList.success!.data!.totalSwap!;
            GlobleConstant.battery_cost =subscriptionResponseList.success!.data!.batteryCost!;
            GlobleConstant.batteryId =subscriptionResponseList.success!.data!.batteryId!;
            GlobleConstant.valid_date_till =subscriptionResponseList.success!.data!.validDateTill!;
            int? totalSwap=subscriptionResponseList.success!.data!.totalSwap;
            int? freeSwap=subscriptionResponseList.success!.data!.freeSwap;
            int noOfSwap=totalSwap!-freeSwap!;
            GlobleConstant.noOfSwap=noOfSwap;
            return subscriptionResponseList;

        }
        else{
          return subscriptionResponseList;

        }

  }
  @override
  Future<BatteryListResponse> getHistoryList (
  String swapstation_id ) async {
    var res = await Utils.postApiCall(Constants.POST_SWAP_BATTRY_HISTORY, {
      "swapstation_id":swapstation_id,
    });


    var jsonresult = json.decode(res.body);
    BatteryListResponse  subscriptionResponseList=BatteryListResponse.fromJson(jsonresult);
    return subscriptionResponseList;
  }
  @override
  Future<CommonApi> getCommonList (
  String swapstation_id ) async {
    var res = await Utils.postApiCall(Constants.POST_SWAP_BATTRY_DIS_LIST, {
      "swapstation_id":swapstation_id,

    });


    var jsonresult = json.decode(res.body);
    CommonApi  subscriptionResponseList=CommonApi.fromJson(jsonresult);
    return subscriptionResponseList;
  }
  @override
  Future<DischargeBattryListResponse> getBattryListList (
  String swapstation_id ) async {
    var res = await Utils.postApiCall(Constants.POST_SWAP_BATTRY_DIS_LIST, {
      "swapstation_id":swapstation_id,

    });


    var jsonresult = json.decode(res.body);
    DischargeBattryListResponse   subscriptionResponseList=DischargeBattryListResponse.fromJson(jsonresult);
    return subscriptionResponseList;
  }



  @override
  Future<MyPlanResponse> getPlanList(
      String commond) async {
    var res = await Utils.postApiCall(
        Constants.POST_PLAN_LIST,
        {"user_id":"${Constants.userId}"});
    var json = jsonDecode(res.body);

    try {
      MyPlanResponse  fcnaDetailResponse =
      MyPlanResponse .fromJson(json);

      return fcnaDetailResponse;
    } catch (e) {
      print(e);
      return MyPlanResponse .fromJson({
        'result': null,
        'statusCode': 0,
        'success': false,
        'systemMsg': "Api not found!",
        'userMsg': "Please check Api",
      });
    }
  }

  @override
  Future<SwapNowResponse>  addSwapeNow(String ev_number, String swapstation_id, String battery_id, String battery_serial_no,payment,remarks) async {
     String paymentData="";
     if(payment.toString()=="Online")
       {
         paymentData="1";

       }
     if(payment.toString()=="Cash")
       {
         paymentData="2";

       }
      if(payment.toString()=="QR Code")
       {
         paymentData="3";

       }
    var res = await Utils.postApiCall(
        Constants.POST_SWAP_NOW,
        {"ev_number":ev_number,"swapstation_id":Constants.swapstation_id,"battery_id":battery_id,"battery_serial_no":battery_serial_no,"payment_mode":paymentData,"remarks":remarks,});
         var json = jsonDecode(res.body);
         print(res);

    try {
      SwapNowResponse  fcnaDetailResponse =
      SwapNowResponse .fromJson(json);

      return fcnaDetailResponse;
    } catch (e) {
      print(e);
      return SwapNowResponse.fromJson({
        'result': null,
        'statusCode': 0,
        'success': false,
        'systemMsg': "Api not found!",
        'userMsg': "Please check Api",
      });
    }
  }

}
