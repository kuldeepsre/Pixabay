import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:station_master/custom_widget/custom_text_blue.dart';
import 'package:station_master/custom_widget/custom_text_normal.dart';
import 'package:station_master/fragments/swap_battry_step_2.dart';
import 'package:station_master/utils/Constants.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/custom_dialog.dart';
import 'package:station_master/utils/text_style.dart';

import '../bloc/gate_bloc/gate_bloc.dart';
import '../custom_widget/custom_loader.dart';
import '../custom_widget/custom_text_normal_24.dart';
import '../custom_widget/custom_text_normal_green_24.dart';
import '../flutter_custom_clippers.dart';

class SwapBattry extends StatefulWidget {
  const SwapBattry({Key? key}) : super(key: key);

  @override
  _GateScreenState createState() => _GateScreenState();
}

class _GateScreenState extends State<SwapBattry> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => GateBloc(GateInitial()),
      child: const Gate2Widget(),
    );
  }
}

class Gate2Widget extends StatefulWidget {
  const Gate2Widget({Key? key}) : super(key: key);

  @override
  _GateWidgetState createState() => _GateWidgetState();
}

class _GateWidgetState extends State<Gate2Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  late bool _validate;
  late bool isLogin;
  var FullNameController = TextEditingController();
  var DateController = TextEditingController();
  var AddressController = TextEditingController();

  var evController=TextEditingController(text: "UP19S9076");
  var remarksController=TextEditingController();
  var newBattryController=TextEditingController(text:"");
  int _currentStep = 0;
  StepperType stepperType = StepperType.vertical;
  bool visible=false;

  bool hide=true;

  String paymentmode="";

  @override
  void initState() {
    super.initState();
    _validate = false;
    visible = false;
    isLogin = false;


  }

  @override
  Widget build(BuildContext context) {
    var widgetMinWidth = 650;
    var totalWidth = MediaQuery.of(context).size.width;
    var totalPadding = 14;
    final gateBloc = BlocProvider.of<GateBloc>(context);
    ScrollController? _scrollController =
    ScrollController(initialScrollOffset: 0);
    return SafeArea(
      child: Scaffold(
          resizeToAvoidBottomInset:false,
          backgroundColor: Colors.white,
          body: BlocListener<GateBloc, GateState>(
            listener: (context, state) {
              if(state is DataGet)
                {
                  setState(() {
                    visible=true;
                  });
                }
              if(state is DataFailed)
                {
                CustomDialogs.showDialogForError(context, "No subscriptions found", "Swap Battery");
                 setState(() {
                  visible=false;
                 });
                }
              if(state is SwapNowFailed)
                {
                CustomDialogs.showDialogForError(context, "Battery not exists swap station", "Swap Battery");
                 setState(() {
                  visible=false;
                 });
                }
              if(state is SwapNowSuccess)
                {
                CustomDialogs.showDialogForError(context, "Swap battery processes has been done", "Swap Battery");
                 setState(() {
                  visible=false;
                  evController.text="";
                 });
                }
            },
            child: BlocBuilder(
              bloc: gateBloc,
              builder: (BuildContext context, GateState state) {
                if (state is GateLoading) {
                  return const Center(child: CustomLoader());
                }
                return SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:  <Widget>[
                      ClipPath(
                        clipper: WaveClipperOne(flip: true),
                        child: Container(
                          height: 120,
                          color: ColorUtils.clip,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children:
                                [
                                  Text("Swap Battery".toUpperCase(),textScaleFactor: 1,style: HeadingStyle,),
                                 // Text("Step-1".toUpperCase(),textScaleFactor: 1,style: HeadingStyle,),
                                ]),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Card(
                        elevation: 16,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const CustomTextNormal24("Enter EV No",),
                              const SizedBox(height: 10,),
                              TextFormField(
                                controller: evController,
                                keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                  filled: true,
                                  fillColor: ColorUtils.table2,
                                  hintText: "",
                                  labelText: "",
                                  hintStyle: const TextStyle(color: Colors.white),
                                ),

                                autocorrect: true,
                                style:
                                TextStyle(fontSize: 20.0, color:ColorUtils.blueColor),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return "Please Enter Owner Name";
                                  } else {
                                    return null;
                                  }
                                },

                              ),
                              const SizedBox(height: 10,),
                              GestureDetector(
                                onTap: (){
                                  gateBloc.add(ValidateList(
                                    id: evController.text.toString()
                                  ));
                                },
                                child: Card(
                                    shape: RoundedRectangleBorder(
                                      side: const BorderSide(color: Colors.lightBlueAccent, width: 1),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Padding(
                                      padding: EdgeInsets.symmetric(horizontal: 28.0,vertical: 20),
                                      child: CustomTextBlue("Validate"),
                                    )),
                              ),
                              Visibility(
                                visible: visible,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [

                                   SingleChildScrollView(
                                    child: Stepper(
                                      type: stepperType,
                                      physics: ScrollPhysics(),
                                      currentStep: _currentStep,
                                      onStepTapped: (step) => tapped(step),
                                      controlsBuilder: (BuildContext context, ControlsDetails controls) {
                                        return Row(
                                            children: <Widget>[
                                              GestureDetector(
                                                onTap: (){
                                                  continued();
                                                },
                                                child: Visibility(
                                                  visible:_currentStep<2?true:false ,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.all(const Radius.circular(15))   ,  gradient: LinearGradient(
                                                      colors: [
                                                        ColorUtils.green1,
                                                        ColorUtils.greenbtn,

                                                      ],
                                                    )
                                                    ),
                                                    child:const Padding(
                                                      padding: EdgeInsets.symmetric(horizontal:30.0,vertical: 12),
                                                      child: Center(
                                                        child: Text(
                                                          "NEXT",
                                                          textScaleFactor: 1,
                                                          style: TextStyle(color: Colors.white),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            const SizedBox(width: 15,),
                                            GestureDetector(
                                              onTap: (){
                                                cancel();
                                              },
                                              child: Visibility(
                                                visible:_currentStep<2?true:false ,
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.all(const Radius.circular(15))   ,  gradient: LinearGradient(
                                                    colors: [
                                                      ColorUtils.green1,
                                                      ColorUtils.btnBlue,

                                                    ],
                                                  )
                                                  ),
                                                  child:const Padding(
                                                    padding: EdgeInsets.symmetric(horizontal:30.0,vertical: 12),
                                                    child: Center(
                                                      child: Text(
                                                        "Back",
                                                        textScaleFactor: 1,
                                                        style: TextStyle(color: Colors.white),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                        ]);
                                      },

                                      steps: <Step>[
                                        Step(
                                          title: const Text('Step-1'),
                                          content: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              const SizedBox(height: 10,),
                                              const CustomTextNormal24("Batter Sr. No"),
                                              const SizedBox(height: 10,),
                                              CustomTextNormalGreen24(GlobleConstant.batterySerialNo.toString()),
                                              const SizedBox(height: 10,),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children:  [
                                                  const CustomTextNormal24("No. of Free Swaps :"),

                                                  CustomTextNormalGreen24(GlobleConstant.noOfSwap.toString(),),

                                                ],
                                              ),
                                              const SizedBox(height: 10,),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children:  [
                                                  CustomTextNormal24("Battery Cost :"),

                                                  CustomTextNormalGreen24("₹ ${GlobleConstant.battery_cost}",),

                                                ],
                                              )   ,
                                              const SizedBox(height: 10,),
                                              const CustomTextNormal24("Payment Mode :"),
                                              const SizedBox(height: 10,),
                                              Container(
                                                width: MediaQuery.of(context).size.width,
                                                color: ColorUtils.table2,

                                                child: DropdownButtonFormField<String>(
                                                  items: <String>['Payment Mode :', 'Online', 'Cash', 'Qr Code'].map((String value) {
                                                    return DropdownMenuItem<String>(
                                                      value: value,
                                                      child: Text(value),
                                                    );
                                                  }).toList(),
                                                  onChanged: ( val) {

                                                    paymentmode=val.toString();
                                                  },
                                                ),
                                              ),
                                              const SizedBox(height: 10,),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children:   [
                                                  CustomTextNormal24("Validity :"),

                                                  CustomTextNormalGreen24(GlobleConstant.valid_date_till.toString(),),

                                                ],
                                              )   ,
                                              const SizedBox(height: 10,),
                                            ],
                                          ),
                                          isActive: _currentStep >= 0,
                                          state: _currentStep >= 0 ?
                                          StepState.complete : StepState.disabled,
                                        ),
                                        Step(
                                          title: const Text('Step-2'),
                                          content: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              const CustomTextNormal24("Remarks",),
                                              const SizedBox(height: 10,),
                                              TextFormField(
                                                controller: remarksController,
                                                keyboardType: TextInputType.text,
                                                decoration: InputDecoration(
                                                  filled: true,
                                                  fillColor: ColorUtils.table2,

                                                 hintText: "",
                                                  labelText: "",
                                                  hintStyle: const TextStyle(color: Colors.white),
                                                ),

                                                autocorrect: true,
                                                style:
                                                TextStyle(fontSize: 20.0, color:ColorUtils.blueColor),
                                                validator: (value) {
                                                  if (value == null || value.isEmpty) {
                                                    return "Please Enter remarks Name";
                                                  } else {
                                                    return null;
                                                  }
                                                },

                                              ),
                                              const SizedBox(height: 20,),
                                              Center(child: Image.asset("assets/sm/qrcode.png",width: 120,height: 120,)),
                                              const SizedBox(height: 30,),
                                            ],
                                          ),
                                          isActive: _currentStep >= 0,
                                          state: _currentStep >= 1 ?
                                          StepState.complete : StepState.disabled,
                                        ),
                                        Step(

                                          title: const Text('Step-3'),
                                          content: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              const CustomTextNormal24("EV No",),
                                              CustomTextNormalGreen24(evController.text.toString()),
                                              const SizedBox(height: 10,),
                                              CustomTextNormal24("Batter Sr. No"),
                                              CustomTextNormalGreen24(GlobleConstant.batterySerialNo.toString()),
                                              const CustomTextNormal24("Enter New Battery Serial No",),
                                              const SizedBox(height: 10,),
                                              TextFormField(
                                                controller: newBattryController,
                                                keyboardType: TextInputType.text,
                                                decoration: InputDecoration(
                                                  filled: true,
                                                  fillColor: ColorUtils.table2,

                                                  hintText: "",
                                                  labelText: "",
                                                  hintStyle: const TextStyle(color: Colors.white),
                                                ),

                                                autocorrect: true,
                                                style:
                                                TextStyle(fontSize: 20.0, color:ColorUtils.blueColor),
                                                validator: (value) {
                                                  if (value == null || value.isEmpty) {
                                                    return "Please New Battery Serial No";
                                                  } else {
                                                    return null;
                                                  }
                                                },

                                              ),
                                              const SizedBox(height: 30,),
                                              GestureDetector(
                                                onTap: (){
                                                   if(paymentmode.isNotEmpty)
                                                     {
                                                       gateBloc.add(SwapNowSave(
                                                           ev_number: evController.text.toString(),swapstation_id:Constants.swapstation_id.toString(),
                                                           battery_id:GlobleConstant.batteryId.toString(), battery_serial_no:newBattryController.text.toString(),payment:paymentmode,remarks:remarksController.text.toString() ));
                                                     }


                                                },
                                                child: Center(
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.all(const Radius.circular(15))   ,  gradient: LinearGradient(
                                                      colors: [
                                                        ColorUtils.green1,
                                                        ColorUtils.green2,

                                                      ],
                                                    )
                                                    ),
                                                    child:const Padding(
                                                      padding: EdgeInsets.symmetric(horizontal:30.0,vertical: 12),
                                                      child: Center(
                                                        child: Text(
                                                          "Swap Now",
                                                          textScaleFactor: 1,
                                                          style: TextStyle(color: Colors.white),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          isActive:_currentStep >= 0,

                                          state: _currentStep >= 2 ?
                                          StepState.complete : StepState.disabled,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),

                    ],
                  ),


                );
              },
            ),
          )),
    );
  }

  tapped(int step){
    setState(() {
  /*    if(step<2)
        {
          hide=false;
        }
      else{
        hide=true;
      }*/

      _currentStep = step;
    });

  }

  continued(){
    _currentStep < 2 ?
    setState(() => _currentStep += 1): null;
  }
   cancel(){
    _currentStep > 0 ?
    setState(() => _currentStep -= 1) : null;
  }


}