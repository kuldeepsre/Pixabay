import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:station_master/model/get_battry_list_response.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/text_style.dart';

import '../bloc/gate_bloc/gate_bloc.dart';
import '../custom_widget/custom_loader.dart';
import '../flutter_custom_clippers.dart';
import '../tabs/home_scrrem.dart';
import '../utils/Constants.dart';
import '../utils/date_time_util.dart';

class DischargeBattery extends StatefulWidget {
  const DischargeBattery({Key? key}) : super(key: key);

  @override
  _GateScreenState createState() => _GateScreenState();
}

class _GateScreenState extends State<DischargeBattery> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => GateBloc(GateInitial()),
      child: const Gate2Widget(),
    );
  }
}

class Gate2Widget extends StatefulWidget {
  const Gate2Widget({Key? key}) : super(key: key);

  @override
  _GateWidgetState createState() => _GateWidgetState();
}

class _GateWidgetState extends State<Gate2Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  late bool _validate;
  late bool isLogin;
  var FullNameController = TextEditingController();
  var DateController = TextEditingController();
  var AddressController = TextEditingController();

  List<BatteryList> _list=[];

  var remarksController=TextEditingController();
  @override
  void initState() {
    super.initState();
    _validate = false;
    isLogin = false;

    final gateBloc = BlocProvider.of<GateBloc>(context);

    gateBloc.add(GetHistoryList(id: Constants.swapstation_id));
  }

  @override
  Widget build(BuildContext context) {
    var widgetMinWidth = 650;
    var totalWidth = MediaQuery.of(context).size.width;
    var totalPadding = 14;
    final gateBloc = BlocProvider.of<GateBloc>(context);
    ScrollController? _scrollController =
    ScrollController(initialScrollOffset: 0);
    return Scaffold(
        resizeToAvoidBottomInset:false,
        backgroundColor: Colors.white,

        body: BlocListener<GateBloc, GateState>(
          listener: (context, state) {
            if(state is DischargeBattryHistoryLoaded)
            {
              _list= state.list;
            }
            if(state is DataSaved)
            {

              GlobleConstant.index=4;
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          Dashboard()),
                      (Route<dynamic> route) => route.isFirst);

            }
          },
          child: BlocBuilder(
            bloc: gateBloc,
            builder: (BuildContext context, GateState state) {
              if (state is GateLoading) {
                return const Center(child: CustomLoader());
              }
              return SingleChildScrollView(
                child: Column(
                  children:  <Widget>[
                    ClipPath(
                      clipper: WaveClipperOne(flip: true),
                      child: Container(
                        height: 120,
                        color: ColorUtils.clip,
                        child: Center(child: Text("Discharge Battery".toUpperCase(),textScaleFactor: 1,style: HeadingStyle,)),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Card(
                            elevation: 15,
                            child: Container(

                              decoration: BoxDecoration(
                                color: ColorUtils.tablleHColor,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 18.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,

                                  children: [
                                    Text("Date",textScaleFactor:1,style: sideMenu14Style,),
                                    Text("Battery Serial No",textScaleFactor:1,style: sideMenu14Style,),
                                    Text("Move To Admin",textScaleFactor:1,style: sideMenu14Style,),
                                    Text("Defect",textScaleFactor:1,style: sideMenu14Style,),

                                  ],
                                ),
                              ),
                            ),
                          ),
                          ListView.builder(
                            shrinkWrap: true,
                            itemCount: _list.length,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              var model=_list[index];
                              return model.workStatus==0?Container(

                                color:( index%2==0)?Colors.white:ColorUtils.even,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 10.0),
                                  child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                                    children: [
                                      SizedBox(
                                          width: MediaQuery.of(context).size.width*.20,
                                          child: Text("${model.manufacturingDate!.isNotEmpty?DateTimeUtils.convertUtcToLocalDate(model.manufacturingDate.toString()):"NA"}",style: buttonBlackTextStyle,)),
                                      SizedBox(
                                          width: MediaQuery.of(context).size.width*.20,

                                          child: Text("${model.batterySerialNo}",style: buttonBlackTextStyle,)),
                                      GestureDetector(
                                        onTap: (){
                                          gateBloc.add(MoveSubmit(id: Constants.swapstation_id,batteryId:model.batteryId.toString()));
                                        },
                                        child: Card(
                                            color: Colors.green,
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Text("Move",textScaleFactor:1,style: buttonBlackTextStyle,),
                                            )),
                                      ),
                                      GestureDetector(
                                        onTap: (){
                                          if(model.workStatus==1)
                                          {
                                            showDialog(
                                                context: context,
                                                builder: (BuildContext context) {
                                                  return AlertDialog(
                                                    shape: const RoundedRectangleBorder(
                                                        borderRadius: BorderRadius.all(Radius.circular(15.0))),
                                                    contentPadding: const EdgeInsets.only(top: 10.0),
                                                    content: SizedBox(
                                                      width: MediaQuery.of(context).size.width*.80,
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        mainAxisSize: MainAxisSize.min,
                                                        children: <Widget>[

                                                          const SizedBox(
                                                            height: 25.0,
                                                          ),
                                                          Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: TextFormField(
                                                              controller: remarksController,
                                                              keyboardType: TextInputType.text,
                                                              decoration: InputDecoration(

                                                                fillColor: Colors.white,

                                                                focusedBorder: OutlineInputBorder(
                                                                    borderSide: BorderSide(
                                                                        color: ColorUtils.greenbtn)),
                                                                border: OutlineInputBorder(
                                                                    borderSide: BorderSide(
                                                                        color: ColorUtils.greenbtn,
                                                                        width: 0.5) //This is Ignored,

                                                                ),
                                                                labelStyle: const TextStyle(
                                                                    color: Colors.black),
                                                                hintText: "Please Enter Remarks",
                                                                labelText: "Remarks",

                                                                hintStyle: const TextStyle(color: Colors.black),
                                                              ),
                                                              style:
                                                              const TextStyle(fontSize: 15.0, color:Colors.black),
                                                              autocorrect: true,
                                                              validator: (value) {
                                                                if (value == null || value.isEmpty) {
                                                                  return "Please Enter remarks";
                                                                } else {
                                                                  return null;
                                                                }
                                                              },

                                                            ),
                                                          ),



                                                          Row(
                                                            children: [
                                                              const Spacer(),
                                                              ElevatedButton(
                                                                onPressed: () {
                                                                  Navigator.pop(context);
                                                                },
                                                                style: ElevatedButton.styleFrom(
                                                                    primary: ColorUtils.app_primary_color),
                                                                child: const Text(
                                                                  "Cancel",
                                                                  style: TextStyle(color: Colors.white),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ),
                                                              const SizedBox(
                                                                width: 08,
                                                              ),
                                                              ElevatedButton(
                                                                onPressed: () {
                                                                  Navigator.pop(context);

                                                                  gateBloc.add(DefectedSubmit(id: Constants.swapstation_id,remarks:remarksController.text.toString(),batteryId:model.batteryId.toString()));

                                                                },
                                                                style: ElevatedButton.styleFrom(
                                                                    primary: ColorUtils.app_primary_color),
                                                                child: const Text(
                                                                  "Submit",
                                                                  style: TextStyle(color: Colors.white),
                                                                  textAlign: TextAlign.center,
                                                                ),
                                                              ),
                                                              const SizedBox(
                                                                width: 16,
                                                              ),
                                                            ],
                                                          ),

                                                          const SizedBox(
                                                            height: 25.0,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  );
                                                });
                                          }

                                        },
                                        child: Card(
                                            color:model.defectStatus==0?Colors.red:Colors.green,
                                            child: Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Text("${model.workStatus==1?"YES":"NO"}",textScaleFactor:1,style: buttonBlackTextStyle,),
                                            )),
                                      ),


                                    ],
                                  ),
                                  Divider(thickness: .5,)
                                ],
                                  ),
                                ),
                              ):
                              Center(child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: index==0?Text("No Records Founds !!",style: redStyle,):Text(""),
                              ))
                              ;
                            },
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ));
  }


}