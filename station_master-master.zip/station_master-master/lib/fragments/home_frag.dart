import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:station_master/fragments/swap_battry.dart';
import 'package:station_master/fragments/swap_history.dart';
import 'package:station_master/utils/Constants.dart';
import 'package:station_master/utils/text_style.dart';
import 'package:station_master/utils/utils.dart';


import '../sign_in.dart';
import '../utils/color_utils.dart';
import 'package:geolocator/geolocator.dart';

import 'package:intl/intl.dart';
import 'package:cron/cron.dart';

import 'package:geocoding/geocoding.dart';

class HomeFragment extends StatefulWidget {
  const HomeFragment({Key? key}) : super(key: key);

  @override
  State<HomeFragment> createState() => _HomeFragmentState();
}

class _HomeFragmentState extends State<HomeFragment> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  void initState() {
    postLive();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Stack(
    children: [
      SizedBox(
        width:MediaQuery.of(context).size.width,
        height:MediaQuery.of(context).size.height,
        child: Padding(
          padding: const EdgeInsets.all(0.0),
          child: Image.asset("assets/sm/dashboard_home.png",fit: BoxFit.fill,),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 30),
        child: Column(

          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
        /*    Text(
              "Welcome to Swap ",textScaleFactor: 1,style: HeadingStyle
            ),*/
            const SizedBox(height: 12,),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: Image.asset("assets/sm/dashboard.png",fit: BoxFit.fitHeight,),
            ),
            const SizedBox(height: 40,),
            Row(

              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                GestureDetector(
                  onTap: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => const SwapBattry()));

                  },
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: const BorderRadius.all(const Radius.circular(15))   ,  gradient: LinearGradient(
                      colors: [
                        ColorUtils.green1,
                        ColorUtils.green2,

                      ],
                    )

                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30.0,vertical: 12),
                      child: Column(
                      children:  [
                        Padding(
                          padding:  const EdgeInsets.all(0.0),
                          child: Image.asset("assets/sm/battery_full.png",width: 32,height: 32,),
                        ),
                        const SizedBox(height: 12,),
                        const Text(
                          "Swap Battery",

                          textScaleFactor: 1,
                          style: TextStyle(color: Colors.white),
                        ),
                      ],
                      ),
                    ),
                  ),
                ),

                GestureDetector(
                  onTap: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => const SwapHistory()));

                  },
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: const BorderRadius.all(const Radius.circular(15))   ,  gradient: LinearGradient(
                      colors: [
                        ColorUtils.green1,
                        ColorUtils.green2,

                      ],
                    )

                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30.0,vertical: 12),
                      child: Column(
                      children:  [
                        Padding(
                          padding:  const EdgeInsets.all(0.0),
                          child: Image.asset("assets/sm/clock.png",width: 32,height: 32,color: Colors.white,),
                        ),
                        const SizedBox(height: 12,),
                        const Text(
                          "Swap History",

                          textScaleFactor: 1,
                          style: TextStyle(color: Colors.white),
                        ),
                      ],
                      ),
                    ),
                  ),
                ),




              ],
            ),
          ],
        ),
      )
    ],
    );
  }
  void postLive() async {

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        print('Location permissions are denied');
      }else if(permission == LocationPermission.deniedForever){
        print("'Location permissions are permanently denied");
      }else{
        print("GPS Location service is granted");
        liveData();
      }
    }
    else{
      print("GPS Location permission granted.");

       liveData();
    }



  }

  Future<void> liveData() async {
    final cron = Cron();

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    var lat = position.latitude;
    var long = position.longitude;
    List<Placemark> placemarks = await placemarkFromCoordinates(lat, long);
    Placemark place = placemarks[0];
    var now = DateTime.now();
    var formatter = DateFormat('yyyy-MM-dd hh-mm-ss');

    String formattedDate = formatter.format(now);
    var   sourceAddress =
        "${place.name},${place.street},${place.subLocality},${place.subThoroughfare},${place.subAdministrativeArea}, ${place.administrativeArea}, ${place
        .country}";
    var res = await Utils.putApiCall("https://evfuel-2cf7c-default-rtdb.firebaseio.com/locationTracking/${Constants.swapstation_id}.json", {
      "address":sourceAddress,
      "id":Constants.swapstation_id,
      "latitude":lat,
      "longitude":long,
      "updated_at":formattedDate,
      "owner_name": Constants.owner_name,
      "on_off":GlobleConstant.open,

    });
    var jsonresult = json.decode(res.body);
    print(jsonresult);
    var snackBar = const SnackBar(content: Text("Locations Updated"));
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
    cron.schedule(Schedule.parse('*/1 * * * *'), () async {

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    var lat = position.latitude;
    var long = position.longitude;
    List<Placemark> placemarks = await placemarkFromCoordinates(lat, long);
    Placemark place = placemarks[0];
    var now = DateTime.now();
    var formatter = DateFormat('yyyy-MM-dd hh-mm-ss');

    String formattedDate = formatter.format(now);
    var   sourceAddress =
        "${place.name},${place.street},${place.subLocality},${place.subThoroughfare},${place.subAdministrativeArea}, ${place.administrativeArea}, ${place
        .country}";
    var res = await Utils.putApiCall("https://evfuel-2cf7c-default-rtdb.firebaseio.com/locationTracking/${Constants.swapstation_id}.json", {
      "address":sourceAddress,
      "id":Constants.swapstation_id,
      "latitude":lat,
      "longitude":long,
      "updated_at":formattedDate,
    "owner_name": Constants.owner_name,

    });
     var jsonresult = json.decode(res.body);
    print(jsonresult);
    var snackBar = const SnackBar(content: Text("Locations Updated"));
     ScaffoldMessenger.of(context).showSnackBar(snackBar);
    });

  }
}