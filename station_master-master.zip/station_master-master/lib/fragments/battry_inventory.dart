import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:station_master/model/battry_list_response.dart';
import 'package:station_master/model/common_response.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/text_style.dart';

import '../bloc/gate_bloc/gate_bloc.dart';
import '../custom_widget/custom_loader.dart';
import '../flutter_custom_clippers.dart';
import '../utils/Constants.dart';

class BattryInventory extends StatefulWidget {
  const BattryInventory({Key? key}) : super(key: key);

  @override
  _GateScreenState createState() => _GateScreenState();
}

class _GateScreenState extends State<BattryInventory> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => GateBloc(GateInitial()),
      child: const Gate2Widget(),
    );
  }
}

class Gate2Widget extends StatefulWidget {
  const Gate2Widget({Key? key}) : super(key: key);

  @override
  _GateWidgetState createState() => _GateWidgetState();
}

class _GateWidgetState extends State<Gate2Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  late bool _validate;
  late bool isLogin;
  var FullNameController = TextEditingController();
  var DateController = TextEditingController();
  var AddressController = TextEditingController();

  List<BatteryListData> _list=[];
  int dis=0;
  int charge=0;
  @override
  void initState() {
    super.initState();
    _validate = false;
    isLogin = false;
    final gateBloc = BlocProvider.of<GateBloc>(context);

    gateBloc.add(CommonList(id: Constants.swapstation_id));
  }

  @override
  Widget build(BuildContext context) {
    var widgetMinWidth = 650;
    var totalWidth = MediaQuery.of(context).size.width;
    var totalPadding = 14;
    final gateBloc = BlocProvider.of<GateBloc>(context);
    ScrollController? _scrollController =
    ScrollController(initialScrollOffset: 0);
    return Scaffold(
        resizeToAvoidBottomInset:false,
        backgroundColor: Colors.white,

        body: BlocListener<GateBloc, GateState>(
          listener: (context, state) {
            if(state is CommonLoaded)
            {
              _list= state.list;
               if(_list.isNotEmpty){

                 for(int i=0;i<_list.length;i++)
                   {

                     int  check=_list[i].workStatus!;
                     if(check==0)
                       {
                         dis++;
                       }
                     else{
                       charge++;
                     }
                   }
               }


            }
          },
          child: BlocBuilder(
            bloc: gateBloc,
            builder: (BuildContext context, GateState state) {
              if (state is GateLoading) {
                return const Center(child: CustomLoader());
              }
              return SingleChildScrollView(
                child: Column(
                  children:  <Widget>[
                    ClipPath(
                      clipper: WaveClipperOne(flip: true),
                      child: Container(
                        height: 120,
                        color: ColorUtils.clip,
                        child: Center(child: Text("Battery Inventory".toUpperCase(),textScaleFactor: 1,style: HeadingStyle,)),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width*.89,

                            decoration: BoxDecoration(
                              color: ColorUtils.table1,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 18.0),
                              child: Center(child: Text("Charge Battery: $charge",textScaleFactor:1,style: listTextStyle,)),

                            ),
                          ),
                          SizedBox(height: 20,),
                          Container(
                            width: MediaQuery.of(context).size.width*.89,

                            decoration: BoxDecoration(
                              color: ColorUtils.table2,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 18.0),
                              child: Center(child: Text("Discharge Battery: $dis",textScaleFactor:1,style: redStyle,)),

                            ),
                          ),

                        ],
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ));
  }


}