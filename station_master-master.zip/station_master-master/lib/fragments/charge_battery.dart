import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/text_style.dart';

import '../bloc/gate_bloc/gate_bloc.dart';
import '../custom_widget/custom_loader.dart';
import '../flutter_custom_clippers.dart';
import '../model/common_response.dart';
import '../utils/Constants.dart';
import '../utils/date_time_util.dart';

class ChargeBattery extends StatefulWidget {
  const ChargeBattery({Key? key}) : super(key: key);

  @override
  _GateScreenState createState() => _GateScreenState();
}

class _GateScreenState extends State<ChargeBattery> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => GateBloc(GateInitial()),
      child: const Gate2Widget(),
    );
  }
}

class Gate2Widget extends StatefulWidget {
  const Gate2Widget({Key? key}) : super(key: key);

  @override
  _GateWidgetState createState() => _GateWidgetState();
}

class _GateWidgetState extends State<Gate2Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  late bool _validate;
  late bool isLogin;
  var FullNameController = TextEditingController();
  var DateController = TextEditingController();
  var AddressController = TextEditingController();
  int dis=0;
  int charge=0;
  List<BatteryListData> _list=[];
  @override
  void initState() {
    super.initState();
    _validate = false;
    isLogin = false;

    final gateBloc = BlocProvider.of<GateBloc>(context);


    gateBloc.add(CommonList(id: Constants.swapstation_id));
  }

  @override
  Widget build(BuildContext context) {
    var widgetMinWidth = 650;
    var totalWidth = MediaQuery.of(context).size.width;
    var totalPadding = 14;
    final gateBloc = BlocProvider.of<GateBloc>(context);
    ScrollController? _scrollController =
    ScrollController(initialScrollOffset: 0);
    return Scaffold(
        resizeToAvoidBottomInset:false,
        backgroundColor: Colors.white,
    
        body: BlocListener<GateBloc, GateState>(
          listener: (context, state) {
            if(state is CommonLoaded)
            {
              _list= state.list;
              if(_list.isNotEmpty){

                for(int i=0;i<_list.length;i++)
                {

                  int  check=_list[i].defectStatus!;
                  if(check==0)
                  {
                    dis++;
                  }
                  else{
                    charge++;
                  }
                }
              }


            }
          },
          child: BlocBuilder(
            bloc: gateBloc,
            builder: (BuildContext context, GateState state) {
              if (state is GateLoading) {
                return const Center(child: CustomLoader());
              }
              return SingleChildScrollView(
                child: Column(
                  children:  <Widget>[
                    ClipPath(
                      clipper: WaveClipperOne(flip: true),
                      child: Container(
                        height: 120,
                        color: ColorUtils.clip,
                        child: Center(child: Text("Charge Battery".toUpperCase(),textScaleFactor: 1,style: HeadingStyle,)),
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        children: [
                          Card(
                            elevation: 15,
                            child: Container(
                              
                              decoration: BoxDecoration(
                                color: ColorUtils.tablleHColor,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceAround,

                                  children: [
                                    Text("Date",style: sideMenuStyle,),
                                    Text("Battery Serial No",style: sideMenuStyle,)

                                  ],
                                ),
                              ),
                            ),
                          ),
                          ListView.separated(
                            shrinkWrap: true,
                            itemCount: _list.length,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              var modle=_list[index];
                              return modle.workStatus==1?Container(
                                color:( index%2==0)?Colors.white:ColorUtils.even,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 18.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                                    children: [
                                      Text("${modle.manufacturingDate!.isNotEmpty?DateTimeUtils.convertUtcToLocalDate(modle.manufacturingDate.toString()):"NA"}",style: buttonBlackTextStyle,),
                                      Text("${modle.batterySerialNo}",style: buttonBlackTextStyle,)

                                    ],
                                  ),
                                ),
                              ):Center(child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: index==0?Text("No Records Founds !!",style: redStyle,):Text(""),
                              ))
                               ;
                            },
                            separatorBuilder: (context, index) {
                              return Divider(thickness: 0,);
                            },
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ));
  }


}