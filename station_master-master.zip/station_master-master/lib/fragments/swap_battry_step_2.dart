import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:station_master/custom_widget/custom_text_blue.dart';
import 'package:station_master/custom_widget/custom_text_normal.dart';
import 'package:station_master/fragments/swap_battry3.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/text_style.dart';

import '../bloc/gate_bloc/gate_bloc.dart';
import '../custom_widget/custom_loader.dart';
import '../custom_widget/custom_text_normal_24.dart';
import '../custom_widget/custom_text_normal_green_24.dart';
import '../flutter_custom_clippers.dart';

class SwapBattryStap2 extends StatefulWidget {
  const SwapBattryStap2({Key? key}) : super(key: key);

  @override
  _GateScreenState createState() => _GateScreenState();
}

class _GateScreenState extends State<SwapBattryStap2> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => GateBloc(GateInitial()),
      child: const Gate2Widget(),
    );
  }
}

class Gate2Widget extends StatefulWidget {
  const Gate2Widget({Key? key}) : super(key: key);

  @override
  _GateWidgetState createState() => _GateWidgetState();
}

class _GateWidgetState extends State<Gate2Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  late bool _validate;
  late bool isLogin;
  var FullNameController = TextEditingController();
  var DateController = TextEditingController();
  var AddressController = TextEditingController();

  var evController=TextEditingController();
  @override
  void initState() {
    super.initState();
    _validate = false;
    isLogin = false;

    final gateBloc = BlocProvider.of<GateBloc>(context);
    gateBloc.add(ParkingDataData(master_name: "parking_allotment"));
    gateBloc.add(ParkingGetListData(parking_allotment: " "));
  }

  @override
  Widget build(BuildContext context) {
    var widgetMinWidth = 650;
    var totalWidth = MediaQuery.of(context).size.width;
    var totalPadding = 14;
    final gateBloc = BlocProvider.of<GateBloc>(context);
    ScrollController? _scrollController =
    ScrollController(initialScrollOffset: 0);
    return SafeArea(

      child: Scaffold(
          resizeToAvoidBottomInset:false,
          backgroundColor: Colors.white,
          appBar: AppBar(
            backgroundColor: ColorUtils.appBarColor,
            flexibleSpace:Center(child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.asset("assets/images/logo.png",fit: BoxFit.contain,width: 100,height: 30,),
            )),


          ),
          body: BlocListener<GateBloc, GateState>(
            listener: (context, state) {

            },
            child: BlocBuilder(
              bloc: gateBloc,
              builder: (BuildContext context, GateState state) {
                if (state is GateLoading) {
                  return const Center(child: CustomLoader());
                }
                return SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:  <Widget>[
                      ClipPath(
                        clipper: WaveClipperOne(flip: true),
                        child: Container(
                          height: 120,
                          color: ColorUtils.clip,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children:
                                [
                                  Text("Swap Battery".toUpperCase(),textScaleFactor: 1,style: HeadingStyle,),
                                  Text("Step-2".toUpperCase(),textScaleFactor: 1,style: HeadingStyle,),
                                ]),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(2.0),
                        child: Card(
                          elevation: 6,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CustomTextNormal24("Remarks",),
                                SizedBox(height: 10,),
                                TextFormField(
                                  controller: evController,
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: ColorUtils.table2,





                                    hintText: "",
                                    labelText: "",
                                    hintStyle: const TextStyle(color: Colors.white),
                                  ),

                                  autocorrect: true,
                                  style:
                                  TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please Enter Owner Name";
                                    } else {
                                      return null;
                                    }
                                  },

                                ),
                                SizedBox(height: 20,),
                                Center(child: Image.asset("assets/sm/qrcode.png",width: 120,height: 120,)),
                                const SizedBox(height: 30,),
                                GestureDetector(
                                  onTap: (){
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => const SwapBattryStap3()),
                                    );
                                  },
                                  child: Center(
                                    child: Container(
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(Radius.circular(15))   ,  gradient: LinearGradient(
                                        colors: [
                                          ColorUtils.green1,
                                          ColorUtils.green2,

                                        ],
                                      )
                                      ),
                                      child:const Padding(
                                        padding: EdgeInsets.symmetric(horizontal:30.0,vertical: 12),
                                        child: Center(
                                          child: Text(
                                            "Next Step",
                                            textScaleFactor: 1,
                                            style: TextStyle(color: Colors.white),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 30,),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              },
            ),
          )),
    );
  }


}