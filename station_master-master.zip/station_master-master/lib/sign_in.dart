// ignore_for_file: prefer_const_constructors

import 'package:station_master/custom_widget/custom_button.dart';
import 'package:station_master/custom_widget/custom_text_blue.dart';

import 'package:station_master/custom_widget/custom_text_normal.dart';
import 'package:station_master/registernow_in.dart';
import 'package:station_master/tabs/home_scrrem.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/custom_dialog.dart';
import 'package:station_master/utils/strings.dart';
import 'package:station_master/utils/text_style.dart';
import 'package:flutter/material.dart';

import 'bloc/gate_bloc/gate_bloc.dart';
import 'bloc/login/login_bloc.dart';
import 'custom_widget/custom_loader.dart';
import 'custom_widget/custom_text_white_normal.dart';
import 'package:flutter_bloc/flutter_bloc.dart';



class SignIn extends StatefulWidget {
  const SignIn({Key? key}) : super(key: key);

  @override
  _GateScreenState createState() => _GateScreenState();
}

class _GateScreenState extends State<SignIn> {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => GateBloc(GateInitial()),
      child: const Gate2Widget(),
    );
  }
}

class Gate2Widget extends StatefulWidget {
  const Gate2Widget({Key? key}) : super(key: key);
  @override
  _GateWidgetState createState() => _GateWidgetState();
}
class _GateWidgetState extends State<Gate2Widget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();
  late bool _validate;
  late bool isLogin;
  var selectProject = "";
  final statusDateControoler = TextEditingController();

  var emailController=TextEditingController(text: "EV700S946");
  var passController=TextEditingController(text: "1234567");

  @override
  void initState() {
    super.initState();
    _validate = false;
    isLogin = false;
  }
  @override
  Widget build(BuildContext context) {
    final gateBloc = BlocProvider.of<GateBloc>(context);
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        body:BlocListener<GateBloc, GateState>(
          listener: (context, state) {
            if(state is DataSaved){
              Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) =>
                          Dashboard()),
                      (Route<dynamic> route) => route.isFirst);
            }
            if(state is DataFailed){
              CustomDialogs.showDialogForError(
                  context, state.message, state.title);
            }
          },
          child: BlocBuilder(
            bloc: gateBloc,
            builder: (BuildContext context, GateState state) {
              if (state is GateLoading) {
                return const CustomLoader();
              }

              return  Stack(
                children: [
                  SizedBox(
                    width:MediaQuery.of(context).size.width,
                    height:MediaQuery.of(context).size.height,
                    child: Image.asset("assets/sm/bg.png",fit: BoxFit.fill,),
                  ),
                  SizedBox(
                    width:MediaQuery.of(context).size.width,
                    height:MediaQuery.of(context).size.height*.30,
                    child: Image.asset("assets/sm/top.png",fit: BoxFit.fill,),
                  ),
                  Form(
                    key: formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children:  <Widget>[
                          SizedBox(   height:MediaQuery.of(context).size.height*.30,),
                          Text(
                            "Login Now".toUpperCase(),
                            textScaleFactor: 1,
                            style: sideMenuStyle,
                          ),
                          const SizedBox(height: 20,),
                          Text(
                            "Please login to get started",
                            textScaleFactor: 1,
                            style: graySubHeadingStyle,
                          ),
                          const SizedBox(height: 10,),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: ListView(
                              physics: NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              children: [
                                TextFormField(
                                  controller: emailController,
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(

                                    fillColor: Colors.white,

                                    focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: ColorUtils.app_primary_color)),
                                    border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: ColorUtils.app_primary_color,
                                            width: 0.5) //This is Ignored,

                                    ),
                                    labelStyle: TextStyle(
                                        color: ColorUtils.whiteColor),
                                    hintText: "",
                                    labelText: "Userid/Email",

                                    hintStyle: const TextStyle(color: Colors.white),
                                  ),
                                  style:
                                  TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                  autocorrect: true,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please Enter Email Id";
                                    } else {
                                      return null;
                                    }
                                  },

                                ),
                                const SizedBox(height: 20,),
                                TextFormField(
                                  controller: passController,
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                    hoverColor: ColorUtils.fillColor,
                                    fillColor: ColorUtils.fillColor,
                                    focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: ColorUtils.app_primary_color)),
                                    border: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            color: ColorUtils.app_primary_color,
                                            width: 0.5) //This is Ignored,

                                    ),
                                    labelStyle: TextStyle(
                                        color: ColorUtils.whiteColor),
                                    hintText: "",
                                    labelText: "Password",
                                    hintStyle: const TextStyle(color: Colors.white),
                                  ),
                                  style:
                                  TextStyle(fontSize: 20.0, color:ColorUtils.whiteColor),
                                  autocorrect: true,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter password";
                                    } else {
                                      return null;
                                    }
                                  },
                                  onChanged: (text) {
                                    setState(() {});
                                    // do something with text
                                  },
                                ),
                                const SizedBox(height: 10,),

                                Align(
                                    alignment: Alignment.topRight,
                                    child: const CustomTextWhiteNormal(Strings.forgotPass)),
                                const SizedBox(height: 10,),
                                SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  child: CustomButton(Strings.login, onClick: () {

                                    if (formKey.currentState!.validate()){
                                      save(context);
                                    }
                                  }, isFullWidth: true),
                                ),
                                const SizedBox(height: 10,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children:  [
                                    CustomTextWhiteNormal(Strings.noAccount),
                                    GestureDetector(
                                        onTap: (){
                                          Navigator.pushAndRemoveUntil(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (BuildContext context) =>
                                                      RegisterNow()),
                                                  (Route<dynamic> route) => route.isFirst);
                                        },
                                        child: CustomTextWhiteNormal(Strings.registerNow)),
                                  ],
                                )
                              ],
                            ),
                          ),


                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        )
      ),

    );
  }
  void save(BuildContext context) {
    final gateBloc = BlocProvider.of<GateBloc>(context);
    gateBloc.add(LoginSubmit(
      email:emailController.text.toString(),
      password:passController.text.toString(),
    ));
  }
}