import 'package:bloc/bloc.dart';
import 'package:station_master/model/battry_list_response.dart';
import 'package:station_master/model/my_plan_response.dart';
import 'package:station_master/model/subscreptions_response.dart';
import 'package:station_master/model/swap_now_response.dart';
import 'package:station_master/services/services.dart';
import 'package:flutter/cupertino.dart';
import 'package:meta/meta.dart';

import '../../model/common_response.dart';
import '../../model/get_battry_list_response.dart';
part 'gate_event.dart';
part 'gate_state.dart';
class GateBloc extends Bloc<GateEvent, GateState> {
  GateBloc(GateInitial gateInitial) : super(GateInitial()) {
    on<GateEvent>((event, emit) async {
      if (event is AddInfo) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.saveRagister(event.owner_name,event.password,event.phone,event.address,event.id_proof,event.email);
        if (res.status==200) {
          emit(DataSaved(message: "Data Saved Successfully", title: 'Register Screen'));
        }else if(res.status==401) {
          emit(DataFailed(
              title: "Error", message:"$res"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is LoginSubmit) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.saveLogin(event.email,event.password);
        if (res.status==200) {
          emit(DataSaved(message: "Data Saved Successfully", title: 'Register Screen'));
        }else if(res.status==401) {
          emit(DataFailed(
              title: "Login Screen", message:"Invalid Credentials"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is DefectedSubmit) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.saveDefected(event.id,event.remarks,event.batteryId);
        if (res.status==200) {
          emit(DataSaved(message: "Data Saved Successfully", title: 'Register Screen'));
        }else if(res.status==401) {
          emit(DataFailed(
              title: "Login Screen", message:"Invalid Credentials"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is MoveSubmit) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.saveMove(event.id,event.batteryId);
        if (res.status==200) {
          emit(DataSaved(message: "Data Saved Successfully", title: 'Register Screen'));
        }else if(res.status==401) {
          emit(DataFailed(
              title: "Login Screen", message:"Invalid Credentials"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is ValidateList) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.getSubscriptionList(event.id);
        if (res.status==200) {
          emit(DataGet());

        }else if(res.status==401) {
          emit(DataFailed(
              title: "subscriptions data", message:"No subscriptions found"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is GetHistoryList) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.getHistoryList(event.id);
        if (res.status==200) {
          emit(SwapHistoryLoaded(list: res.success!.swapHistory!));

        }else if(res.status==401) {
          emit(DataFailed(
              title: "subscriptions data", message:"No subscriptions found"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is CommonList) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.getCommonList(event.id);
        if (res.status==200) {
          emit(CommonLoaded(list: res.success!.batteryList!));

        }else if(res.status==401) {
          emit(DataFailed(
              title: "subscriptions data", message:"No subscriptions found"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is GetHistoryList) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.getBattryListList(event.id);
        if (res.status==200) {
          emit(DischargeBattryHistoryLoaded(list: res.success!.batteryList!));

        }else if(res.status==401) {
          emit(DataFailed(
              title: "subscriptions data", message:"No subscriptions found"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is SwapNowSave) {
        emit(GateLoading());
        final service = FetchService();
        var res =
        await service.addSwapeNow(event.ev_number,event.swapstation_id,event.battery_id,event.battery_serial_no,event.payment,event.remarks);
        if (res.status==200) {
          emit(SwapNowSuccess( title: "", message:""));

        }else if(res.status==401) {
          emit(SwapNowFailed(
              title: "subscriptions data", message:"No subscriptions found"));
        }
        else{
          emit(DataFailed(
              title: "Error", message:"server error"));
        }
      }
      if (event is GetPlanList) {
        emit(GateLoading());
        final gateData = FetchService();
        var res = await gateData.getPlanList(event.id);
        if (res.status==200) {

          emit(PlanDataLoaded(planList: res.success!));
        }
        else {
          emit(UserTokenExpired(
              title: "Token !!", message:"Token has been Expired"));
        }
      }
    });
  }
}
