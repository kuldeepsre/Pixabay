part of 'gate_bloc.dart';

@immutable
abstract class GateState {}

class GateInitial extends GateState {}

class UserTokenExpired extends GateState {
  final String title, message;

  UserTokenExpired({required this.title, required this.message});
}

class GateLoading extends GateState {}

class SuggestionLoading extends GateState {}

class DataSaved extends GateState {
  final String title, message;

  DataSaved({required this.title, required this.message});
}

class PlanSaved extends GateState {
  final String title, message;

  PlanSaved({required this.title, required this.message});
}

class DataDelete extends GateState {
  final String title, message;

  DataDelete({required this.title, required this.message});
}

class SearchDataLoaded extends GateState {
  final List<SuccessData> subscriptionList;

  SearchDataLoaded({required this.subscriptionList});
}

class SwapHistoryLoaded extends GateState {
  final List<SwapHistoryData> list;

  SwapHistoryLoaded({required this.list});
}class CommonLoaded extends GateState {
  final List<BatteryListData> list;

  CommonLoaded({required this.list});
}
class DischargeBattryHistoryLoaded extends GateState {
  final List<BatteryList> list;

  DischargeBattryHistoryLoaded({required this.list});
}

class PlanDataLoaded extends GateState {
  PlanResponse planList;

  PlanDataLoaded({required this.planList});
}

class DataFailed extends GateState {
  final String title, message;

  DataFailed({required this.title, required this.message});
}

class SwapNowFailed extends GateState {
  final String title, message;

  SwapNowFailed({required this.title, required this.message});
}

class SwapNowSuccess extends GateState {
  final String title, message;

  SwapNowSuccess({required this.title, required this.message});
}

class DataGet extends GateState {
}


