import 'package:flutter/material.dart';
import 'package:station_master/registernow_in.dart';
import 'package:station_master/sign_in.dart';
import 'package:station_master/utils/color_utils.dart';
import 'package:station_master/utils/text_style.dart';



void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home:  MyHomePage(title: "",),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(

      body: Stack(
       children: [
         SizedBox(
           width:MediaQuery.of(context).size.width,
           height:MediaQuery.of(context).size.height,
           child: Padding(
             padding: const EdgeInsets.all(0.0),
             child: Image.asset("assets/sm/splash.png",fit: BoxFit.fitHeight,),
           ),
         ),

         Column(
           children: [
              SizedBox(height:MediaQuery.of(context).size.height*.12,),
             SizedBox(
               width:MediaQuery.of(context).size.width,
               height:MediaQuery.of(context).size.height*.30,
               child: Padding(
                 padding: const EdgeInsets.all(30.0),
                 child: Image.asset("assets/images/logo.png",fit: BoxFit.contain,),
               ),
             ),
             const SizedBox(height: 30,),
             Text(
               "EV Fuel Mobility".toUpperCase(),
               textScaleFactor: 1,
               style:sideMenuStyle,
             ),
             const SizedBox(height: 30,),





           ],
         ),
         Positioned(
           bottom: 0.0,
           child: Container(
             width: MediaQuery.of(context).size.width,

             margin: const EdgeInsets.all(0.0),
             child: Column(
               mainAxisAlignment: MainAxisAlignment.center,
               children:  <Widget>[
                 Text(
                   "Swap Station Login".toUpperCase(),
                   textScaleFactor: 1,
                   style:sideMenuBlack,
                 ),
                 const SizedBox(height: 40,),
                 Align(
                   alignment: Alignment.bottomCenter,
                   child: ButtonBar(

                     alignment: MainAxisAlignment.center,
                     children: <Widget>[
                       GestureDetector(
                         onTap: (){
                           Navigator.pushAndRemoveUntil(
                               context,
                               MaterialPageRoute(
                                   builder: (BuildContext context) =>
                                       const SignIn()),
                                   (Route<dynamic> route) => route.isFirst);
                         },
                         child: Container(
                           decoration: BoxDecoration(
                               borderRadius: BorderRadius.all(Radius.circular(15))   ,  gradient: LinearGradient(
                             colors: [
                               ColorUtils.green1,
                               ColorUtils.green2,

                             ],
                           )

                           ),
                           child:const Padding(
                             padding: EdgeInsets.symmetric(horizontal: 30.0,vertical: 12),
                             child: Text(
                               "Login",
                               textScaleFactor: 1,
                               style: TextStyle(color: Colors.white),
                             ),
                           ),
                         ),
                       ),
                       GestureDetector(
                         onTap: (){
                           Navigator.pushAndRemoveUntil(
                               context,
                               MaterialPageRoute(
                                   builder: (BuildContext context) =>
                                       RegisterNow()),
                                   (Route<dynamic> route) => route.isFirst);
                         },
                         child: Container(
                           decoration: BoxDecoration(
                               borderRadius: BorderRadius.all(Radius.circular(15))   ,  gradient: LinearGradient(
                             colors: [
                               ColorUtils.Create1ln,
                               ColorUtils.Create2ln,

                             ],
                           )
                           ),
                           child:const Padding(
                             padding: EdgeInsets.symmetric(horizontal:30.0,vertical: 12),
                             child: Text(
                               "Register",
                               textScaleFactor: 1,
                               style: TextStyle(color: Colors.white),
                             ),
                           ),
                         ),
                       ),




                     ],
                   ),
                 ),
                 const SizedBox(height: 20,),
               ],
             ),
           ),
         ),


       ],
      ),


    );

  }
}
