class SwapNowResponse {
  Success? success;
  int? status;

  SwapNowResponse({this.success, this.status});

  SwapNowResponse.fromJson(Map<String, dynamic> json) {
    success =
    json['success'] != null ? new Success.fromJson(json['success']) : null;
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.success != null) {
      data['success'] = this.success!.toJson();
    }
    data['status'] = this.status;
    return data;
  }
}

class Success {
  Data? data;

  Success({this.data});

  Success.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? id;
  String? batterySerialNo;
  String? batteryName;
  String? manufacturingDate;
  int? status;
  String? createdAt;
  String? updatedAt;
  int? assignStatus;
  int? workStatus;
  int? assignSwapstationStatus;
  int? adminExist;
  int? defectStatus;
  Null? remarks;

  Data(
      {this.id,
        this.batterySerialNo,
        this.batteryName,
        this.manufacturingDate,
        this.status,
        this.createdAt,
        this.updatedAt,
        this.assignStatus,
        this.workStatus,
        this.assignSwapstationStatus,
        this.adminExist,
        this.defectStatus,
        this.remarks});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    batterySerialNo = json['battery_serial_no'];
    batteryName = json['battery_name'];
    manufacturingDate = json['manufacturing_date'];
    status = json['status'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    assignStatus = json['assign_status'];
    workStatus = json['work_status'];
    assignSwapstationStatus = json['assign_swapstation_status'];
    adminExist = json['admin_exist'];
    defectStatus = json['defect_status'];
    remarks = json['remarks'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['battery_serial_no'] = this.batterySerialNo;
    data['battery_name'] = this.batteryName;
    data['manufacturing_date'] = this.manufacturingDate;
    data['status'] = this.status;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['assign_status'] = this.assignStatus;
    data['work_status'] = this.workStatus;
    data['assign_swapstation_status'] = this.assignSwapstationStatus;
    data['admin_exist'] = this.adminExist;
    data['defect_status'] = this.defectStatus;
    data['remarks'] = this.remarks;
    return data;
  }
}