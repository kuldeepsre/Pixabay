class CommonApi {
  Success? success;
  int? status;

  CommonApi({this.success, this.status});

  CommonApi.fromJson(Map<String, dynamic> json) {
    success =
    json['success'] != null ? new Success.fromJson(json['success']) : null;
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.success != null) {
      data['success'] = this.success!.toJson();
    }
    data['status'] = this.status;
    return data;
  }
}

class Success {
  List<BatteryListData>? batteryList;

  Success({this.batteryList});

  Success.fromJson(Map<String, dynamic> json) {
    if (json['batteryList'] != null) {
      batteryList = <BatteryListData>[];
      json['batteryList'].forEach((v) {
        batteryList!.add(new BatteryListData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.batteryList != null) {
      data['batteryList'] = this.batteryList!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class BatteryListData {
  int? batteryId;
  String? batterySerialNo;
  String? batteryName;
  String? manufacturingDate;
  int? defectStatus;
  int? workStatus;

  BatteryListData(
      {this.batteryId,
        this.batterySerialNo,
        this.batteryName,
        this.manufacturingDate,
        this.defectStatus,
        this.workStatus});

  BatteryListData.fromJson(Map<String, dynamic> json) {
    batteryId = json['battery_id'];
    batterySerialNo = json['battery_serial_no'];
    batteryName = json['battery_name'];
    manufacturingDate = json['manufacturing_date'];
    defectStatus = json['defect_status'];
    workStatus = json['work_status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['battery_id'] = this.batteryId;
    data['battery_serial_no'] = this.batterySerialNo;
    data['battery_name'] = this.batteryName;
    data['manufacturing_date'] = this.manufacturingDate;
    data['defect_status'] = this.defectStatus;
    data['work_status'] = this.workStatus;
    return data;
  }
}