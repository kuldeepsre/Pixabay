class SubscriptionResponseList {
  SuccessResult? success;
  int? status;

  SubscriptionResponseList({this.success, this.status});

  SubscriptionResponseList.fromJson(Map<String, dynamic> json) {
    success =
    json['success'] != null ? new SuccessResult.fromJson(json['success']) : null;
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.success != null) {
      data['success'] = this.success!.toJson();
    }
    data['status'] = this.status;
    return data;
  }
}

class SuccessResult {
  Data? data;

  SuccessResult({this.data});

  SuccessResult.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? subscriptionId;
  int? batteryId;
  String? batterySerialNo;
  int? freeSwap;
  int? totalSwap;
  int? batteryCost;
  String? validDateTill;

  Data(
      {this.subscriptionId,
        this.batteryId,
        this.batterySerialNo,
        this.freeSwap,
        this.totalSwap,
        this.batteryCost,
        this.validDateTill});

  Data.fromJson(Map<String, dynamic> json) {
    subscriptionId = json['subscription_id'];
    batteryId = json['battery_id'];
    batterySerialNo = json['battery_serial_no'];
    freeSwap = json['free_swap'];
    totalSwap = json['total_swap'];
    batteryCost = json['battery_cost'];
    validDateTill = json['valid_date_till'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['subscription_id'] = this.subscriptionId;
    data['battery_id'] = this.batteryId;
    data['battery_serial_no'] = this.batterySerialNo;
    data['free_swap'] = this.freeSwap;
    data['total_swap'] = this.totalSwap;
    data['battery_cost'] = this.batteryCost;
    data['valid_date_till'] = this.validDateTill;
    return data;
  }
}