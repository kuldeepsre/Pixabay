class BatteryListResponse {
  Success? success;
  int? status;

  BatteryListResponse({this.success, this.status});

  BatteryListResponse.fromJson(Map<String, dynamic> json) {
    success =
    json['success'] != null ? new Success.fromJson(json['success']) : null;
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.success != null) {
      data['success'] = this.success!.toJson();
    }
    data['status'] = this.status;
    return data;
  }
}

class Success {
  List<SwapHistoryData>? swapHistory;

  Success({this.swapHistory});

  Success.fromJson(Map<String, dynamic> json) {
    if (json['swapHistory'] != null) {
      swapHistory = <SwapHistoryData>[];
      json['swapHistory'].forEach((v) {
        swapHistory!.add(new SwapHistoryData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.swapHistory != null) {
      data['swapHistory'] = this.swapHistory!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SwapHistoryData {
  String? evNumber;
  String? providedDate;
  String? returnDate;
  String? batterySerialNo;

  SwapHistoryData(
      {this.evNumber,
        this.providedDate,
        this.returnDate,
        this.batterySerialNo});

  SwapHistoryData.fromJson(Map<String, dynamic> json) {
    evNumber = json['ev_number'];
    providedDate = json['provided_date']??"";
    returnDate = json['return_date']??"";
    batterySerialNo = json['battery_serial_no'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ev_number'] = this.evNumber;
    data['provided_date'] = this.providedDate;
    data['return_date'] = this.returnDate;
    data['battery_serial_no'] = this.batterySerialNo;
    return data;
  }
}