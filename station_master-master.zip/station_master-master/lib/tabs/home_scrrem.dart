
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:station_master/fragments/discharge.dart';
import 'package:station_master/fragments/home_frag.dart';

import 'package:intl/intl.dart';

import 'package:station_master/utils/text_style.dart';
import 'package:cron/cron.dart';
import '../fragments/battry_inventory.dart';
import '../fragments/charge_battery.dart';
import '../fragments/swap_battry.dart';
import '../fragments/swap_history.dart';
import '../utils/Constants.dart';
import '../utils/color_utils.dart';
import '../utils/custom_dialog.dart';
import '../utils/utils.dart';
import 'package:geolocator/geolocator.dart';


import 'package:geocoding/geocoding.dart';
class DrawerItem {
  String title;
  IconData icon;
  Color color;
  DrawerItem(this.title, this.icon, this.color);
}

class Dashboard extends StatefulWidget {
  final drawerItems = [
    DrawerItem("Home", Icons.home,ColorUtils.whiteColor),
    DrawerItem("Swap Battery", Icons.grid_view_rounded,ColorUtils.whiteColor),
    DrawerItem("Battery inventory", Icons.inventory,ColorUtils.whiteColor),
    DrawerItem("Charge Battery", Icons.battery_charging_full_sharp,ColorUtils.whiteColor),
    DrawerItem("Discharge Battery",Icons.battery_unknown_outlined,ColorUtils.whiteColor),
    DrawerItem("Swap History", Icons.history,ColorUtils.whiteColor),
  ];


  @override
  State<StatefulWidget> createState() {
    return DashboardState();
  }
}

class DashboardState extends State<Dashboard> {
  int _selectedDrawerIndex =GlobleConstant.index;

  _getDrawerItemWidget(int pos) {
    switch (pos) {
      case 0:
        return const HomeFragment();
      case 1:
        return const SwapBattry();
      case 2:
        return const BattryInventory();
      case 3:
        return const ChargeBattery();
        case 4:
        return const DischargeBattery();
       case 5:
        return const SwapHistory();

      default:
        return const Text("Error");
    }
  }

  _onSelectItem(int index) {
    setState(() => _selectedDrawerIndex = index);
    Navigator.of(context).pop(); // close the drawer
  }



/*
     @override
  void initState() {
     postLive();
    super.initState();
  }
*/

  @override
  Widget build(BuildContext context) {
    List<Widget> drawerOptions = [];
    for (var i = 0; i < widget.drawerItems.length; i++) {
      var d = widget.drawerItems[i];
      drawerOptions.add(
          ListTile(
            leading: Icon(d.icon,color: ColorUtils.whiteColor,),
            title: Text(d.title,style: sideMenuStyle,),
            selected: i == _selectedDrawerIndex,
            onTap: () => _onSelectItem(i),
          )
      );
    }

    return SafeArea(
      child: WillPopScope(
        onWillPop: () => CustomDialogs.onBackPressed(context),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: ColorUtils.appBarColor,
            flexibleSpace:Center(child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.asset("assets/images/logo.png",fit: BoxFit.contain,width: 100,height: 30,),
            )),

            actions: [
              GestureDetector(
                onTap: (){
                 if(
                 GlobleConstant.open=="Open"
                 )
                   {
                     GlobleConstant.open=="Closed";
                   }

                 else{
                   GlobleConstant.open=="Open";
                 }
                },
                child: Card(
                 color: GlobleConstant.open=="Open"? Colors.white:Colors.red,
                  child: Text(
                    GlobleConstant.open=="Open"?GlobleConstant.open:GlobleConstant.open,
                    textScaleFactor: 1,
                    style: TextStyle(
                      color: GlobleConstant.open=="Open"? Colors.white:Colors.white,
                      fontSize: 14.0,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              )
            ],


          ),
          drawer: Drawer(
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(const Radius.circular(0))   ,  gradient: LinearGradient(
                colors: [
                  ColorUtils.blue1,
                  ColorUtils.blue2,

                ],
              )

              ),
              child: Stack(
                children: [
                  Column(
                    children: <Widget>[
                      Image.asset("assets/images/logo.png",),
                      Column(children: drawerOptions),
                    ],
                  ),
                  GestureDetector(
                    onTap: (){
                      CustomDialogs.showLogoutConfirmation(context);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 30.0,horizontal: 20),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          height: MediaQuery.of(context).size.height*.06,
                          decoration: const BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(15))   ,gradient: LinearGradient(
                            colors: [
                              Colors.white,
                              Colors.white,
                           ],
                          )

                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children:  [
                              Image.asset("assets/images/logout.png",color: Colors.green,),
                              const Padding(
                                padding: EdgeInsets.symmetric(horizontal: 8.0),
                                child: Text(
                                  "Logout",
                                  textScaleFactor: 1,
                                  style: TextStyle(
                                    color: Colors.green,
                                    fontSize: 14.0,
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],

              ),
            ),
          ),
          body: _getDrawerItemWidget(_selectedDrawerIndex),
        ),
      ),
    );
  }

  Future<void> liveData() async {
    final cron = Cron();

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    var lat = position.latitude;
    var long = position.longitude;
    List<Placemark> placemarks = await placemarkFromCoordinates(lat, long);
    Placemark place = placemarks[0];
    var now = DateTime.now();
    var formatter = DateFormat('yyyy-MM-dd hh-mm-ss');

    String formattedDate = formatter.format(now);
    var   sourceAddress =
        "${place.name},${place.street},${place.subLocality},${place.subThoroughfare},${place.subAdministrativeArea}, ${place.administrativeArea}, ${place
        .country}";
    var res = await Utils.putApiCall("https://evfuel-2cf7c-default-rtdb.firebaseio.com/locationTracking/${Constants.swapstation_id}.json", {
      "address":sourceAddress,
      "id":Constants.swapstation_id,
      "latitude":lat,
      "longitude":long,
      "updated_at":formattedDate,
      "owner_name": Constants.owner_name,

    });
    var jsonresult = json.decode(res.body);
    print(jsonresult);
    var snackBar = const SnackBar(content: Text("Locations Updated"));
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
    cron.schedule(Schedule.parse('*/1 * * * *'), () async {

      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      var lat = position.latitude;
      var long = position.longitude;
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, long);
      Placemark place = placemarks[0];
      var now = DateTime.now();
      var formatter = DateFormat('yyyy-MM-dd hh-mm-ss');

      String formattedDate = formatter.format(now);
      var   sourceAddress =
          "${place.name},${place.street},${place.subLocality},${place.subThoroughfare},${place.subAdministrativeArea}, ${place.administrativeArea}, ${place
          .country}";
      var res = await Utils.putApiCall("https://evfuel-2cf7c-default-rtdb.firebaseio.com/locationTracking/${Constants.swapstation_id}.json", {
        "address":sourceAddress,
        "id":Constants.swapstation_id,
        "latitude":lat,
        "longitude":long,
        "updated_at":formattedDate,
        "owner_name": Constants.owner_name,

      });
      var jsonresult = json.decode(res.body);
      print(jsonresult);
      var snackBar = const SnackBar(content: Text("Locations Updated"));
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
    });

  }
}