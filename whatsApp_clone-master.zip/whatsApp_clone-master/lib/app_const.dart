

class AppConst {
  //MessageType
  static String text="TEXT";
  static String image="IMAGE";
  static String audio="AUDIO";
  static String video="VIDEO";

  //communication Type
  static String oneToOneChat="oneToOneChat";
  static String groupChat="groupChat";
}